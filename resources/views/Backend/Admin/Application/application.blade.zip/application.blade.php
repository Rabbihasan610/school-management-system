@extends('Backend.Admin.master')
@section('title')
    Application Canidate
@endsection

@section('content')
    <!-- Breadcubs Area Start Here -->
    <div class="breadcrumbs-area">
        <h3>@yield('title')</h3>
        <ul>
            <li>
                <a href="{{route('admin.dashboard')}}">Home</a>
            </li>
            <li>@yield('title')</li>
        </ul>
    </div>

    <!-- Breadcubs Area End Here -->
  
            <div class="card">
                <div class="card-header">
                    Application Canidate
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                <table class="table display data-table text-nowrap">
                    <thead>
                    <tr>
                        <th>
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input checkAll">
                                <label class="form-check-label">ID</label>
                            </div>
                        </th>
                        <th>Name</th>
                        <th>email</th>
                        <th>phone</th>
                        <th>Trade Name</th>
                        <th>Course Name</th>
                        <th>Image</th>
                        <th>Action</th>

                    </tr>
                    </thead>
                    <tbody>
                    @foreach($application_canidates as $app_can)
                    <tr>
                        <td>
                            {{ $loop->index +1 }}
                        </td>
                        <td>{{ $app_can->name }}</td>
                        <td>{{ $app_can->email }}</td>
                        <td>{{ $app_can->phone }}</td>
                        <td>{{ $app_can->trade_id }}</td>
                        <td>{{ $app_can->course_id }}</td>
                        <td>
                            @if($app_can->image)
                            <img src="{{asset($app_can->image)}}" alt="" width="100px" height="100px">
                            @else
                                <img src="{{asset('assets/backend/img/default.jpg')}}" alt="" width="100px" height="100px">
                            @endif
                        </td>
                       {{--  <td class="badge badge-pill badge-{{$app_can->status==1 ? 'success':'danger'}} d-block mg-t-8">{{$app_can->status==1 ? 'Active':'Inactive'}}</td> --}}
                        <td>

                                        <a class="btn btn-info text-white"  data-toggle="modal" data-target="#exampleModalCenter_{{$app_can->id}}">View</a>
                                     {{--    <a class="dropdown-item" href="" ><i class="fas fa-arrow-{{  $app_can->status == 1 ? "circle-up" : "circle-down" }}"></i></a> --}}

                                        <button class="btn btn-danger delete_btn" value="{{$app_can->id}}" id="delete" >Delete</button>

                                        <div class="modal fade" id="exampleModalCenter_{{$app_can->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    
                                            <div class="modal-dialog modal-lg" role="document" >
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalCenterTitle">Applicant Details</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        
                                                        <div class="card">
                                                            <div class="card-header">
                                                                Student Info
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="row">
                                                                    <div class="col-6">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Name</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->name }}"  />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Student Photo</label>
                                                                            <div>
                                                                                 @if($app_can->image)
                                                                                  <img src="{{asset($app_can->image)}}" alt="" width="100px" height="100px">
                                                                                @else
                                                                                    <img src="{{asset('assets/backend/img/default.jpg')}}" alt="" width="100px" height="100px">
                                                                                @endif
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-6">
                                                                         <div class="form-group">
                                                                            <label for="name" class="text-muted">Email address</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->email }}"  />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Cannot understand</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->secondery_email }}"  />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                 <div class="row">
                                                                    <div class="col-6">
                                                                         <div class="form-group">
                                                                            <label for="name" class="text-muted">Mobile Number</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->phone }}"  />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">BirthDate</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->date }}"  />
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                 <div class="row">
                                                                    <div class="col-6">
                                                                         <div class="form-group">
                                                                            <label for="name" class="text-muted">Gender</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->email }}"  />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Blood Group</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->blood_group }}"  />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                 <div class="row">
                                                                    <div class="col-6">
                                                                         <div class="form-group">
                                                                            <label for="name" class="text-muted">Religion</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->religion }}"  />
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Nationality</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->nationality }}"  />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                           
                                                        </div>

                                                         <div class="row px-3">
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                        SSC Info
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Roll</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->ssc_roll }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Registration</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->ssc_registation }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Board</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->ssc_borad }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Depertment</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->ssc_depertment }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">GPA</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->ssc_gpa }}"  />
                                                                        </div>
                                                                    </div>
                                                               </div>
                                                           </div>
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                        Application Info
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">School Nmae</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->school_id }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Trade</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->trades->trade_title) ? $app_can->trades->trade_title : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Course</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->courses->course_name) ? $app_can->courses->course_name : ''}}"  />
                                                                        </div>
                                                                
                                                                    </div>
                                                               </div>
                                                           </div>
                                                       </div>
                                                           
                                                       <div class="row px-3">
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                        Father Info
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Father's Name</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->father_name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Father's Email</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->father_email) ? $app_can->father_email : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Father's Phone</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->father_phone) ? $app_can->father_phone : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Father's NID</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->father_nid }}"  />
                                                                        </div>
                                                                    </div>
                                                               </div>
                                                           </div>
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                        Mother Info
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Mother's Name</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->mother_name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Mother's Email</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->mother_email) ? $app_can->mother_email : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Mother's Phone</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->mother_phone) ? $app_can->mother_phone : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Mother's NID</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->mother_nid) ? $app_can->mother_nid : '' }}"  />
                                                                        </div>
                                                                    </div>
                                                               </div>
                                                           </div>
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                       LOCAL GUARDIAN:
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Local guardian Name</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->local_guardian_name) ? $app_can->local_guardian_name : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Local guardian Email</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->local_guardian_email) ? $app_can->local_guardian_email : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Local guardian Phone</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->local_guardian_phone) ? $app_can->local_guardian_phone : '' }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Local guardian NID</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->local_guardian_nid) ? $app_can->local_guardian_nid : '' }}"  />
                                                                        </div>
                                                                    </div>
                                                               </div>
                                                           </div>
                                                       </div>
                                                       <div class="row px-3">
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                        PRESENT ADDRESS:
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Division</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->divisions->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">District</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->districts->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Thana/Upozila</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->thanas->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Union</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->unions->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Village</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ $app_can->village }}"  />
                                                                        </div>
                                                                    </div>
                                                               </div>
                                                           </div>
                                                           <div class="col-6">
                                                               <div class="card">
                                                                    <div class="card-header">
                                                                        PERMANANT ADDRESS:
                                                                    </div>
                                                                    <div class="card-body">
                                                                         <div class="form-group">
                                                                            <label for="name" class="text-muted">Division</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->per_divisions) ? $app_can->per_divisions->name :   $app_can->divisions->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">District</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->per_districts) ? $app_can->per_districts->name : $app_can->districts->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Thana/Upozila</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->per_thanas) ? $app_can->per_thanas->name :  $app_can->thanas->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Union</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->per_union) ? $app_can->per_unions->name : $app_can->unions->name }}"  />
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name" class="text-muted">Village</label>
                                                                            <input type="text" disabled class="text-muted form-control"  value="{{ isset($app_can->per_village) ? $app_can->per_village :  $app_can->village }}"  />
                                                                        </div>
                                                                    </div>
                                                               </div>
                                                           </div>
                                                       </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                   </div>
                                 </div>
                           
                          {{--   <script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>

                            <script>
                                CKEDITOR.replace( 'editor_{{$banner->id}}' );
                            </script> --}}

                        </td>
                    </tr>
                    @endforeach

                    </tbody>
                </table>
            </div>
                </div>
            </div>
       

@endsection



@section('js')
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" ></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).ready(function (){

            $(document).on('click', '.delete_btn', function (e){
                e.preventDefault();
                let emp_id = $(this).val();



                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if(result){
                        if (result.isConfirmed) {
                            $.ajax({
                                type:"GET",
                                url:"application/delete/"+emp_id,
                                success:function (response){
                                    if(response.status == 200) {
                                        window.location.reload();
                                    }
                                }
                            })
                        }
                    }
                })


            });



        })
    </script>



@endsection
